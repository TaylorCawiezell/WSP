(function($){




$('#search-button').click(function() {
    window.location.href = 'result.html';
    return false;
});

$('#sign-up-button').click(function() {
    window.location.href = 'sign-up.html';
    return false;
});








})(jQuery); // end private scope
